SELECT * FROM villagers
WHERE name LIKE :name