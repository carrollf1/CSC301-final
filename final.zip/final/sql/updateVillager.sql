UPDATE villagers
SET 
	name = :name