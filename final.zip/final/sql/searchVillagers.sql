SELECT * FROM villagers
WHERE name LIKE '%$term%';