INSERT INTO villagers(name, gender, personality, catchphrase)
VALUES(:name, :gender, :personality, :catchphrase)